----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-11-20 6:49 pm CST
----------------------------------------------------------------

------  ------------------------------------------------------------  ------------------------
PAYEMS  All Employees, Total Nonfarm, Thousands of Persons, Monthly,  Data Updated: 2026-11-06
        Seasonally Adjusted
UNRATE  Unemployment Rate, Percent, Monthly, Seasonally Adjusted      Data Updated: 2026-11-06
ICSA    Initial Claims, Number, Weekly, Seasonally Adjusted           Data Updated: 2026-11-19
------  ------------------------------------------------------------  ------------------------

